export class patient{
    name:string="";
    address:string="";
    id:number =0;
}