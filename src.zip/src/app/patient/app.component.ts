import { Component } from '@angular/core';
import {patient} from "./app.model"
@Component({
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  patientobj:patient=new patient();
patientarray :Array<patient>=new Array<patient>();
save:boolean=true;
update:boolean=false;

  title = 'hospitalsystem';
  Addpatient(){
    this.patientobj.id=this.patientarray.length;
    this.patientarray.push(this.patientobj);
  this.patientobj=new patient();
  
  
  }
  editpatient(p:patient ){
    this.save=false;
    this.update=true;
var pat=new patient();
pat.name=p.name;
pat.address=p.address;
pat.id=p.id;
this.patientobj=pat;

  }
  updatepatient(){

    this.save=true;
    this.update=false;
var pati:patient=this.patientarray[this.patientobj.id];
pati.name=this.patientobj.name;
pati.address=this.patientobj.address;
this.patientobj=new patient();
  }
deletepatient(pat:patient){
  this.patientarray.splice(pat.id,1);

}

}
